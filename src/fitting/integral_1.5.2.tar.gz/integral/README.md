Calculates joint density of a bayesian model with tripple integral
